import { useState, useEffect, useMemo, useRef, type ReactNode } from 'react'
import nekoLogo from '@/imports/neko_eyer_logo.png'

// ── Types ─────────────────────────────────────────────────────────────────────

interface Planet {
  id: string
  name: string
  radius: number
  orbitRadius: number
  period: number
  color: string
  glow: string
  type: string
  distanceAU: number
  moons: number
  tempC: string
  description: string
  initialOffset: number
}

interface Star {
  id: number
  x: number
  y: number
  size: number
  opacity: number
  delay: number
  duration: number
}

// ── Data ──────────────────────────────────────────────────────────────────────

const SUN: Planet = {
  id: 'sun',
  name: 'The Sun',
  radius: 28,
  orbitRadius: 0,
  period: 0,
  color: '#FFD700',
  glow: 'rgba(255,200,50,0.7)',
  type: 'G-type Main-Sequence Star',
  distanceAU: 0,
  moons: 0,
  tempC: '5,500°C (surface)',
  description: "Our star — 99.86% of the Solar System's total mass, 1.4 million km in diameter, 4.6 billion years old.",
  initialOffset: 0,
}

const PLANETS: Planet[] = [
  {
    id: 'mercury', name: 'Mercury', radius: 4, orbitRadius: 72, period: 3,
    color: '#b0a090', glow: 'rgba(176,160,144,0.4)',
    type: 'Terrestrial', distanceAU: 0.39, moons: 0, tempC: '−180 / +430°C',
    description: 'Smallest planet. Extreme temperature swings, no atmosphere, heavily cratered surface.',
    initialOffset: 0.12,
  },
  {
    id: 'venus', name: 'Venus', radius: 7, orbitRadius: 104, period: 7.5,
    color: '#FFC649', glow: 'rgba(255,198,73,0.4)',
    type: 'Terrestrial', distanceAU: 0.72, moons: 0, tempC: '+465°C',
    description: 'Hottest planet. Dense CO₂ atmosphere with sulfuric acid clouds trapping heat.',
    initialOffset: 0.42,
  },
  {
    id: 'earth', name: 'Earth', radius: 8, orbitRadius: 138, period: 10,
    color: '#4B9CD3', glow: 'rgba(75,156,211,0.4)',
    type: 'Terrestrial', distanceAU: 1.00, moons: 1, tempC: '−89 / +58°C',
    description: 'The only confirmed harbor of life in the universe. Liquid water, breathable atmosphere.',
    initialOffset: 0.70,
  },
  {
    id: 'mars', name: 'Mars', radius: 5, orbitRadius: 174, period: 18.8,
    color: '#C1440E', glow: 'rgba(193,68,14,0.4)',
    type: 'Terrestrial', distanceAU: 1.52, moons: 2, tempC: '−125 / +20°C',
    description: 'Red planet home to Olympus Mons, the tallest volcano in the Solar System at 21 km.',
    initialOffset: 0.25,
  },
  {
    id: 'jupiter', name: 'Jupiter', radius: 20, orbitRadius: 235, period: 50,
    color: '#C88B3A', glow: 'rgba(200,139,58,0.4)',
    type: 'Gas Giant', distanceAU: 5.20, moons: 95, tempC: '−110°C',
    description: 'Largest planet. The Great Red Spot is a storm raging continuously for over 350 years.',
    initialOffset: 0.58,
  },
  {
    id: 'saturn', name: 'Saturn', radius: 17, orbitRadius: 284, period: 120,
    color: '#FAD5A5', glow: 'rgba(250,213,165,0.4)',
    type: 'Gas Giant', distanceAU: 9.58, moons: 146, tempC: '−140°C',
    description: 'Iconic ring system spanning 280,000 km. Less dense than water.',
    initialOffset: 0.82,
  },
  {
    id: 'uranus', name: 'Uranus', radius: 13, orbitRadius: 322, period: 250,
    color: '#7DE8E8', glow: 'rgba(125,232,232,0.35)',
    type: 'Ice Giant', distanceAU: 19.22, moons: 28, tempC: '−224°C',
    description: 'Rotates on its side at 98°. Faint rings, blue-green methane atmosphere.',
    initialOffset: 0.35,
  },
  {
    id: 'neptune', name: 'Neptune', radius: 12, orbitRadius: 360, period: 500,
    color: '#4B70DD', glow: 'rgba(75,112,221,0.35)',
    type: 'Ice Giant', distanceAU: 30.05, moons: 16, tempC: '−214°C',
    description: 'Strongest winds in the Solar System — 2,100 km/h. Has a Great Dark Spot storm.',
    initialOffset: 0.55,
  },
]

function makeStars(count: number): Star[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 1.7 + 0.3,
    opacity: Math.random() * 0.5 + 0.12,
    delay: Math.random() * 7,
    duration: Math.random() * 3 + 2,
  }))
}

// ── StarField ─────────────────────────────────────────────────────────────────

function StarField({ count = 120 }: { count?: number }) {
  const stars = useMemo(() => makeStars(count), [count])
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {stars.map(s => (
        <div
          key={s.id}
          className="absolute rounded-full bg-white"
          style={{
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: s.size,
            height: s.size,
            opacity: s.opacity,
            animation: `twinkle ${s.duration}s ease-in-out ${s.delay}s infinite alternate`,
          }}
        />
      ))}
    </div>
  )
}

// ── GlassPanel ────────────────────────────────────────────────────────────────

function GlassPanel({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`glass rounded-xl border border-nk-cyan/10 shadow-2xl ${className}`}>
      {children}
    </div>
  )
}

// ── SolarSystem ───────────────────────────────────────────────────────────────

function SolarSystem({
  selectedPlanet,
  onSelectPlanet,
  isPlaying,
}: {
  selectedPlanet: Planet | null
  onSelectPlanet: (p: Planet) => void
  isPlaying: boolean
}) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const [scale, setScale] = useState(1)

  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const obs = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect
      setScale(Math.min(width, height) / 800)
    })
    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  return (
    <div ref={wrapRef} className="absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-space-950" />
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1711560026656-814d5a9e980f?w=1920&h=1080&fit=crop&auto=format)',
          opacity: 0.2,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-space-950/15 to-space-950/60 pointer-events-none" />

      {/* Subtle perspective grid */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(rgba(0,216,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,216,255,1) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
          opacity: 0.022,
        }}
      />

      <StarField count={230} />

      {/* Scaled solar system */}
      <div
        className="absolute"
        style={{
          width: 800,
          height: 800,
          top: '50%',
          left: '50%',
          transform: `translate(-50%, -50%) scale(${scale})`,
          transformOrigin: 'center center',
        }}
      >
        {/* Sun corona */}
        <div
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 280,
            height: 280,
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            background: 'radial-gradient(circle, rgba(255,200,50,0.18) 0%, rgba(255,120,0,0.06) 45%, transparent 70%)',
          }}
        />

        {/* Orbit rings */}
        {PLANETS.map(p => (
          <div
            key={`ring-${p.id}`}
            className="absolute rounded-full pointer-events-none"
            style={{
              width: p.orbitRadius * 2,
              height: p.orbitRadius * 2,
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              border: `1px solid ${selectedPlanet?.id === p.id ? 'rgba(0,216,255,0.4)' : 'rgba(99,151,255,0.08)'}`,
              transition: 'border-color 0.5s ease',
            }}
          />
        ))}

        {/* Asteroid belt */}
        <div
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 416,
            height: 416,
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            border: '1px dashed rgba(180,170,140,0.1)',
          }}
        />

        {/* Sun */}
        <div
          className="absolute rounded-full cursor-pointer z-10 transition-transform duration-200 hover:scale-110"
          style={{
            width: 56,
            height: 56,
            top: '50%',
            left: '50%',
            transform: selectedPlanet?.id === 'sun'
              ? 'translate(-50%, -50%) scale(1.15)'
              : 'translate(-50%, -50%)',
            background: 'radial-gradient(circle at 35% 30%, #fff5a0 0%, #ffd700 45%, #ff8c00 100%)',
            boxShadow: selectedPlanet?.id === 'sun'
              ? '0 0 50px 16px rgba(255,200,50,0.7), 0 0 100px 30px rgba(255,120,0,0.35), 0 0 0 2px rgba(0,216,255,0.7)'
              : '0 0 40px 12px rgba(255,200,50,0.55), 0 0 80px 24px rgba(255,120,0,0.22)',
            animation: 'pulse-sun 4s ease-in-out infinite',
            transition: 'box-shadow 0.4s ease',
          }}
          onClick={() => onSelectPlanet(SUN)}
        />

        {/* Planets */}
        {PLANETS.map(p => (
          <div key={`arm-${p.id}`}>
            <div
              className="absolute"
              style={{
                top: '50%',
                left: '50%',
                width: 0,
                height: 0,
                transformOrigin: '0 0',
                animation: `spin ${p.period}s linear infinite`,
                animationPlayState: isPlaying ? 'running' : 'paused',
                animationDelay: `-${p.initialOffset * p.period}s`,
              }}
            >
              {p.id === 'saturn' && (
                <div
                  className="absolute pointer-events-none"
                  style={{
                    width: p.radius * 4.4,
                    height: p.radius * 1.35,
                    left: p.orbitRadius - p.radius * 2.2,
                    top: -p.radius * 0.675,
                    border: '2.5px solid rgba(250,213,165,0.45)',
                    borderRadius: '50%',
                  }}
                />
              )}
              <div
                className="absolute rounded-full cursor-pointer transition-all duration-200"
                style={{
                  width: p.radius * 2,
                  height: p.radius * 2,
                  left: p.orbitRadius - p.radius,
                  top: -p.radius,
                  background:
                    p.id === 'earth'
                      ? `radial-gradient(circle at 35% 30%, #7dd4f6, ${p.color} 55%, #2e7a2c)`
                      : p.id === 'jupiter'
                      ? `radial-gradient(circle at 40% 35%, ${p.color}, #8b5e2a 70%)`
                      : p.id === 'saturn'
                      ? `radial-gradient(circle at 38% 32%, #fff0d0, ${p.color} 55%, #c8a060)`
                      : `radial-gradient(circle at 35% 30%, ${p.color}cc, ${p.color} 60%, ${p.color}77)`,
                  boxShadow:
                    selectedPlanet?.id === p.id
                      ? `0 0 16px 6px ${p.glow}, 0 0 0 2px rgba(0,216,255,0.75)`
                      : `0 0 7px 2px ${p.glow}`,
                  transform: selectedPlanet?.id === p.id ? 'scale(1.2)' : 'scale(1)',
                  transition: 'box-shadow 0.3s, transform 0.3s',
                }}
                onClick={() => onSelectPlanet(p)}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── CameraControls ────────────────────────────────────────────────────────────

function CameraControls({ mode, onModeChange }: { mode: string; onModeChange: (m: string) => void }) {
  return (
    <GlassPanel className="p-3 flex flex-col gap-1 min-w-[152px]">
      <div className="text-[10px] font-mono text-nk-cyan/60 uppercase tracking-[0.15em] px-1 pb-1">
        Camera
      </div>
      {['Free', 'Orbit', 'Track'].map(m => (
        <button
          key={m}
          className={`text-xs px-3 py-1.5 rounded-lg font-mono transition-all duration-200 text-left border ${
            mode === m.toLowerCase()
              ? 'bg-nk-cyan/15 text-nk-cyan border-nk-cyan/35 shadow-[0_0_12px_rgba(0,216,255,0.15)]'
              : 'text-stellar-dim hover:text-stellar hover:bg-white/5 border-transparent'
          }`}
          onClick={() => onModeChange(m.toLowerCase())}
        >
          {m === 'Free' ? '↕ Free' : m === 'Orbit' ? '⟳ Orbit' : '◎ Track'}
        </button>
      ))}
      <div className="border-t border-white/5 mt-1.5 pt-2">
        <div className="text-[10px] font-mono text-nk-cyan/60 uppercase tracking-[0.12em] px-1 mb-1.5">
          Viewport
        </div>
        <div className="flex gap-1.5 justify-between px-1">
          {[['−', 'Zoom out'], ['+', 'Zoom in'], ['⟲', 'Reset']].map(([icon, title]) => (
            <button
              key={icon}
              title={title}
              className="flex-1 h-7 rounded-lg glass-light border border-white/10 text-stellar-dim hover:text-stellar hover:border-nk-cyan/30 transition-all text-sm flex items-center justify-center"
            >
              {icon}
            </button>
          ))}
        </div>
      </div>
    </GlassPanel>
  )
}

// ── ObjectInfoPanel ───────────────────────────────────────────────────────────

function ObjectInfoPanel({ planet, onClose }: { planet: Planet | null; onClose: () => void }) {
  if (!planet) return null

  return (
    <GlassPanel className="p-4 w-64 md:w-[280px]">
      {/* Header */}
      <div className="flex justify-between items-start mb-3">
        <div className="min-w-0">
          <div className="text-[10px] font-mono text-nk-cyan/65 uppercase tracking-[0.15em] truncate">
            {planet.type}
          </div>
          <h3 className="text-xl font-display font-bold text-stellar mt-0.5 leading-tight">
            {planet.name}
          </h3>
        </div>
        <button
          onClick={onClose}
          className="text-stellar-dim/50 hover:text-stellar w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/10 transition-all text-sm flex-shrink-0 ml-2"
        >
          ✕
        </button>
      </div>

      {/* Planet visual + description */}
      <div className="flex items-start gap-3 mb-4 p-3 rounded-lg bg-white/3 border border-white/5">
        <div
          className="rounded-full flex-shrink-0"
          style={{
            width: 40,
            height: 40,
            background: `radial-gradient(circle at 35% 30%, ${planet.color}cc, ${planet.color} 60%, ${planet.color}55)`,
            boxShadow: `0 0 18px 5px ${planet.glow}`,
          }}
        />
        <p className="text-[11px] text-stellar-dim leading-relaxed">{planet.description}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-1.5 mb-3">
        {([
          ['Distance', planet.id === 'sun' ? '—' : `${planet.distanceAU} AU`],
          ['Moons', planet.id === 'sun' ? '8 planets' : String(planet.moons)],
          ['Temperature', planet.tempC],
          ['Class', planet.type.split(' ').slice(-1)[0]],
        ] as [string, string][]).map(([label, value]) => (
          <div key={label} className="bg-white/5 rounded-lg p-2 border border-white/4">
            <div className="text-[9px] text-stellar-dim/45 font-mono uppercase tracking-wider">{label}</div>
            <div className="text-[11px] text-stellar font-mono mt-0.5 leading-snug">{value}</div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <button className="flex-1 text-[11px] font-mono py-2 rounded-lg bg-nk-cyan/15 text-nk-cyan border border-nk-cyan/30 hover:bg-nk-cyan/25 hover:shadow-[0_0_12px_rgba(0,216,255,0.15)] transition-all">
          Focus Camera
        </button>
        <button className="flex-1 text-[11px] font-mono py-2 rounded-lg glass-light border border-white/10 text-stellar-dim hover:text-stellar hover:border-white/18 transition-all">
          More Info
        </button>
      </div>
    </GlassPanel>
  )
}

// ── TimeControlBar ────────────────────────────────────────────────────────────

function TimeControlBar({
  isPlaying,
  onToggle,
  speed,
  onSpeedChange,
}: {
  isPlaying: boolean
  onToggle: () => void
  speed: number
  onSpeedChange: (v: number) => void
}) {
  const presets = [
    { v: 0.1, label: '×0.1' },
    { v: 1, label: '×1' },
    { v: 5, label: '×5' },
    { v: 10, label: '×10' },
  ]

  return (
    <GlassPanel className="px-4 py-2.5 flex items-center gap-4 flex-wrap">
      {/* Epoch */}
      <div className="text-[10px] font-mono leading-tight flex-shrink-0">
        <div className="text-nk-cyan/50 uppercase tracking-[0.12em]">Epoch</div>
        <div className="text-stellar mt-0.5">2025 · 08 · 19</div>
      </div>

      <div className="w-px h-7 bg-white/8 flex-shrink-0" />

      {/* Play/pause */}
      <button
        onClick={onToggle}
        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all flex-shrink-0 ${
          isPlaying
            ? 'bg-nk-cyan/20 border border-nk-cyan/40 text-nk-cyan hover:bg-nk-cyan/30 shadow-[0_0_10px_rgba(0,216,255,0.2)]'
            : 'bg-white/10 border border-white/20 text-stellar hover:bg-white/15'
        }`}
      >
        <span className="text-[11px]">{isPlaying ? '⏸' : '▶'}</span>
      </button>

      {/* Speed presets */}
      <div className="flex gap-1">
        {presets.map(({ v, label }) => (
          <button
            key={v}
            className={`text-[10px] font-mono px-2 py-1 rounded-md transition-all ${
              Math.abs(speed - v) < 0.06
                ? 'bg-nk-cyan/20 text-nk-cyan border border-nk-cyan/30'
                : 'text-stellar-dim hover:text-stellar glass-light border border-white/8 hover:border-white/18'
            }`}
            onClick={() => onSpeedChange(v)}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="w-px h-7 bg-white/8 flex-shrink-0 hidden sm:block" />

      {/* Slider */}
      <div className="hidden sm:flex items-center gap-2">
        <input
          type="range"
          min="0.1"
          max="10"
          step="0.1"
          value={speed}
          onChange={e => onSpeedChange(parseFloat(e.target.value))}
          className="w-20"
        />
        <span className="text-[10px] font-mono text-nk-cyan w-8 flex-shrink-0">×{speed.toFixed(1)}</span>
      </div>
    </GlassPanel>
  )
}

// ── PlanetSelector ────────────────────────────────────────────────────────────

function PlanetSelector({ selected, onSelect }: { selected: Planet | null; onSelect: (p: Planet) => void }) {
  return (
    <GlassPanel className="py-2 px-1.5 flex flex-col gap-0.5">
      <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-[0.15em] px-2 py-1">
        Objects
      </div>
      {[SUN, ...PLANETS].map((p, i) => (
        <button
          key={p.id}
          className={`flex items-center gap-2 px-2 py-1.5 rounded-lg transition-all w-full text-left border ${
            selected?.id === p.id
              ? 'bg-nk-cyan/12 border-nk-cyan/28 shadow-[0_0_8px_rgba(0,216,255,0.1)]'
              : 'hover:bg-white/5 border-transparent'
          } ${i === 0 ? 'mb-0.5' : ''}`}
          onClick={() => onSelect(p)}
        >
          <div
            className="rounded-full flex-shrink-0"
            style={{
              width: p.id === 'sun' ? 10 : 8,
              height: p.id === 'sun' ? 10 : 8,
              background: p.color,
              boxShadow: `0 0 5px ${p.glow}`,
            }}
          />
          <span className="text-[11px] font-mono text-stellar-dim">{p.name}</span>
          {selected?.id === p.id && (
            <span className="ml-auto w-1 h-1 rounded-full bg-nk-cyan animate-pulse" />
          )}
        </button>
      ))}
    </GlassPanel>
  )
}

// ── CoordinateDisplay ─────────────────────────────────────────────────────────

function CoordinateDisplay() {
  return (
    <GlassPanel className="p-3">
      <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-[0.15em] mb-1.5">
        Position
      </div>
      <div className="space-y-0.5 text-[11px] font-mono">
        {[
          ['RA', '10h 42m 31.8s', false],
          ['Dec', '+22° 14′ 09″', false],
          ['Dist', '1.000 AU', true],
          ['Vel', '29.78 km/s', false],
        ].map(([k, v, accent]) => (
          <div key={k as string}>
            <span className="text-stellar-dim/45">{k} </span>
            <span className={accent ? 'text-nk-cyan' : 'text-stellar'}>{v}</span>
          </div>
        ))}
      </div>
    </GlassPanel>
  )
}

// ── DiscoveryHint ─────────────────────────────────────────────────────────────

function DiscoveryHint({ visible }: { visible: boolean }) {
  return (
    <div
      className={`transition-all duration-400 ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-1 pointer-events-none'
      }`}
    >
      <GlassPanel className="px-4 py-2.5 flex items-center gap-3 border-white/8">
        <div className="w-1.5 h-1.5 rounded-full bg-nk-cyan/45 animate-pulse flex-shrink-0" />
        <span className="text-[11px] font-mono text-stellar-dim/50">
          Click any planet or the Sun to explore
        </span>
      </GlassPanel>
    </div>
  )
}

// ── ExplorerStatusBar ─────────────────────────────────────────────────────────

function ExplorerStatusBar({ selectedPlanet, isPlaying }: { selectedPlanet: Planet | null; isPlaying: boolean }) {
  return (
    <div className="absolute bottom-0 inset-x-0 h-7 flex items-center px-5 justify-between pointer-events-none z-10">
      <div
        className="absolute inset-0"
        style={{ background: 'linear-gradient(to top, rgba(1,6,16,0.7), transparent)' }}
      />
      <div className="relative flex items-center gap-4 text-[9px] font-mono text-stellar-dim/28 uppercase tracking-[0.15em]">
        <span>9 objects</span>
        <span className="text-stellar-dim/15">·</span>
        <span>4.6 Gyr</span>
        <span className="text-stellar-dim/15">·</span>
        <span>Ecliptic plane</span>
        {selectedPlanet && (
          <>
            <span className="text-stellar-dim/15">·</span>
            <span className="text-nk-cyan/40">Tracking: {selectedPlanet.name}</span>
          </>
        )}
      </div>
      <div className="relative flex items-center gap-2 text-[9px] font-mono text-stellar-dim/20">
        <span
          className="w-1 h-1 rounded-full flex-shrink-0"
          style={{ background: isPlaying ? 'rgba(0,216,255,0.4)' : 'rgba(122,156,196,0.3)' }}
        />
        <span>{isPlaying ? 'LIVE' : 'PAUSED'}</span>
      </div>
    </div>
  )
}

// ── Header ────────────────────────────────────────────────────────────────────

function Header() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const links = [
    { href: '#hero', label: 'Home' },
    { href: '#explorer', label: 'Explorer' },
    { href: '#design-system', label: 'Design' },
    { href: '#components', label: 'Components' },
  ]

  return (
    <header className="fixed top-0 inset-x-0 z-50">
      {/* Layered background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Nebula texture — always present, dims on scroll */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-opacity duration-700"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1709139450016-5874ed75359e?w=1440&h=80&fit=crop&auto=format)',
            opacity: scrolled ? 0.08 : 0.32,
          }}
        />
        {/* Overlay — glass on scroll, gradient on top */}
        <div
          className="absolute inset-0 transition-all duration-500"
          style={{
            background: scrolled
              ? 'rgba(2,8,19,0.82)'
              : 'linear-gradient(to bottom, rgba(1,6,16,0.55) 0%, rgba(2,8,19,0.2) 100%)',
            backdropFilter: scrolled ? 'blur(22px) saturate(160%)' : 'none',
          }}
        />
        {/* Animated bottom border */}
        <div
          className="absolute bottom-0 inset-x-0 h-px transition-opacity duration-500"
          style={{
            background:
              'linear-gradient(90deg, transparent 0%, rgba(0,216,255,0.18) 25%, rgba(0,216,255,0.38) 50%, rgba(0,216,255,0.18) 75%, transparent 100%)',
            opacity: scrolled ? 1 : 0,
          }}
        />
        {/* Subtle bottom gradient for readability when not scrolled */}
        {!scrolled && (
          <div
            className="absolute bottom-0 inset-x-0 h-6"
            style={{ background: 'linear-gradient(to top, rgba(2,8,19,0.3), transparent)' }}
          />
        )}
      </div>

      {/* Nav content */}
      <div className="relative max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#hero" className="flex items-center gap-2.5 group flex-shrink-0">
          <img
            src={nekoLogo}
            alt="Neko Eyes — space cat logo"
            className="w-9 h-9 object-contain transition-all duration-300 group-hover:drop-shadow-[0_0_10px_rgba(0,216,255,0.6)]"
          />
          <span className="font-display font-semibold text-lg tracking-wide text-stellar leading-none">
            Neko<span className="text-nk-cyan"> Eyes</span>
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-0.5">
          {links.map(l => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-mono px-4 py-2 rounded-lg text-stellar-dim hover:text-stellar hover:bg-white/6 transition-all duration-200"
            >
              {l.label}
            </a>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <span className="text-[10px] font-mono text-stellar-dim/25 border border-white/8 px-2 py-1 rounded">
            V0
          </span>
          <a
            href="#explorer"
            className="inline-flex items-center gap-2 text-sm font-mono px-4 py-2 rounded-lg bg-nk-cyan/15 border border-nk-cyan/30 text-nk-cyan hover:bg-nk-cyan/25 hover:shadow-[0_0_20px_rgba(0,216,255,0.2)] transition-all"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-nk-cyan animate-pulse" />
            Launch Explorer
          </a>
        </div>

        {/* Mobile burger */}
        <button
          className="md:hidden text-stellar p-2 flex flex-col gap-1.5 items-center justify-center w-9 h-9"
          onClick={() => setMobileOpen(o => !o)}
          aria-label="Toggle navigation"
        >
          {mobileOpen ? (
            <span className="text-xl leading-none text-stellar-dim">✕</span>
          ) : (
            <>
              <div className="w-5 h-px bg-stellar" />
              <div className="w-5 h-px bg-stellar" />
              <div className="w-5 h-px bg-stellar" />
            </>
          )}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div
          className="md:hidden border-t border-nk-cyan/8 px-6 py-4 flex flex-col gap-1"
          style={{ background: 'rgba(2,8,19,0.95)', backdropFilter: 'blur(24px)' }}
        >
          {links.map(l => (
            <a
              key={l.href}
              href={l.href}
              className="font-mono text-sm py-3 px-2 text-stellar-dim hover:text-stellar border-b border-white/5 transition-colors last:border-b-0"
              onClick={() => setMobileOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#explorer"
            className="mt-3 text-center font-mono text-sm py-3 rounded-xl bg-nk-cyan/15 border border-nk-cyan/30 text-nk-cyan"
            onClick={() => setMobileOpen(false)}
          >
            Launch Explorer
          </a>
        </div>
      )}
    </header>
  )
}

// ── HeroSection ───────────────────────────────────────────────────────────────

function HeroSection() {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 80)
    return () => clearTimeout(t)
  }, [])

  const fade = (delay: string) =>
    `transition-all duration-700 ${delay} ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`

  return (
    <section id="hero" className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Nebula background */}
      <div className="absolute inset-0 bg-space-950">
        <img
          src="https://images.unsplash.com/photo-1677926405168-fa86268b7295?w=1920&h=1080&fit=crop&auto=format"
          alt="Carina Nebula deep sky background"
          className="w-full h-full object-cover object-center"
          style={{ opacity: 0.52 }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-space-950/65 via-space-950/22 to-space-950/92" />
        <div className="absolute inset-0 bg-gradient-to-r from-space-950/50 via-transparent to-space-950/50" />
      </div>

      {/* Header readability gradient */}
      <div className="absolute top-0 inset-x-0 h-32 bg-gradient-to-b from-space-950/70 to-transparent pointer-events-none z-10" />

      <StarField count={180} />

      {/* Subtle constellation SVG overlay */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ opacity: 0.07 }}>
        <line x1="8%" y1="22%" x2="14%" y2="35%" stroke="white" strokeWidth="0.5" />
        <line x1="14%" y1="35%" x2="11%" y2="48%" stroke="white" strokeWidth="0.5" />
        <line x1="11%" y1="48%" x2="18%" y2="55%" stroke="white" strokeWidth="0.5" />
        <circle cx="8%" cy="22%" r="1.8" fill="white" />
        <circle cx="14%" cy="35%" r="2.2" fill="white" />
        <circle cx="11%" cy="48%" r="1.5" fill="white" />
        <circle cx="18%" cy="55%" r="2" fill="white" />
        <line x1="82%" y1="18%" x2="88%" y2="28%" stroke="white" strokeWidth="0.5" />
        <line x1="88%" y1="28%" x2="92%" y2="20%" stroke="white" strokeWidth="0.5" />
        <line x1="92%" y1="20%" x2="87%" y2="12%" stroke="white" strokeWidth="0.5" />
        <line x1="78%" y1="42%" x2="84%" y2="52%" stroke="white" strokeWidth="0.5" />
        <line x1="84%" y1="52%" x2="90%" y2="48%" stroke="white" strokeWidth="0.5" />
        <circle cx="82%" cy="18%" r="2" fill="white" />
        <circle cx="88%" cy="28%" r="2.5" fill="white" />
        <circle cx="92%" cy="20%" r="1.8" fill="white" />
        <circle cx="87%" cy="12%" r="1.5" fill="white" />
        <circle cx="78%" cy="42%" r="1.5" fill="white" />
        <circle cx="84%" cy="52%" r="2" fill="white" />
        <circle cx="90%" cy="48%" r="1.2" fill="white" />
      </svg>

      {/* Hero content */}
      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto flex flex-col items-center">
        {/* Logo with orbit ring */}
        <div className={`${fade('delay-0')} relative inline-flex items-center justify-center mb-7`}>
          {/* Outer orbit ring */}
          <div
            className="absolute rounded-full pointer-events-none"
            style={{
              width: loaded ? 128 : 120,
              height: loaded ? 128 : 120,
              border: '1px solid rgba(0,216,255,0.22)',
              animation: 'spin 10s linear infinite',
              transition: 'width 0.7s, height 0.7s',
            }}
          >
            {/* Orbiting dot */}
            <div
              className="absolute rounded-full"
              style={{
                width: 6,
                height: 6,
                top: -3,
                left: '50%',
                transform: 'translateX(-50%)',
                background: '#00d8ff',
                boxShadow: '0 0 8px rgba(0,216,255,0.8)',
              }}
            />
          </div>
          {/* Inner ring */}
          <div
            className="absolute rounded-full pointer-events-none"
            style={{
              width: 104,
              height: 104,
              border: '1px solid rgba(0,216,255,0.1)',
              animation: 'spin-reverse 16s linear infinite',
            }}
          />
          <img
            src={nekoLogo}
            alt="Neko Eyes — space cat with orbital rings"
            className="w-24 h-24 md:w-28 md:h-28 object-contain relative z-10"
            style={{
              filter:
                'drop-shadow(0 0 20px rgba(0,216,255,0.4)) drop-shadow(0 0 60px rgba(68,138,255,0.25))',
            }}
          />
        </div>

        {/* Badge */}
        <div className={fade('delay-75')}>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-nk-cyan/22 bg-nk-cyan/7 text-nk-cyan text-[11px] font-mono uppercase tracking-[0.15em] mb-7">
            <div className="w-1.5 h-1.5 rounded-full bg-nk-cyan animate-pulse" />
            Solar System Explorer · V0
          </div>
        </div>

        {/* Title */}
        <h1 className={`${fade('delay-100')} font-display font-bold leading-none mb-4`}>
          <span className="block text-6xl md:text-8xl text-stellar">Neko</span>
          <span
            className="block text-7xl md:text-9xl"
            style={{
              background: 'linear-gradient(135deg, #7df9ff 0%, #00d8ff 40%, #448aff 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Eyes
          </span>
        </h1>

        {/* Subtitle */}
        <p className={`${fade('delay-150')} text-base md:text-lg text-stellar-dim leading-relaxed max-w-md mx-auto mb-10`}>
          Traverse the Solar System in real time. Explore planetary orbits, discover celestial bodies, and journey across 4.5 billion years of cosmic history.
        </p>

        {/* CTAs */}
        <div className={`${fade('delay-200')} flex flex-col sm:flex-row items-center justify-center gap-3`}>
          <a
            href="#explorer"
            className="inline-flex items-center gap-2.5 px-6 py-3 rounded-xl font-mono text-sm font-semibold bg-nk-cyan text-space-900 hover:bg-[#22e3ff] transition-all hover:shadow-[0_0_28px_rgba(0,216,255,0.5)] active:scale-95"
          >
            Begin Exploration
            <span className="text-base">→</span>
          </a>
          <a
            href="#design-system"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-mono text-sm glass border border-white/10 text-stellar-dim hover:text-stellar hover:border-nk-cyan/22 transition-all"
          >
            Design System
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-35">
        <span className="text-[10px] font-mono text-stellar-dim uppercase tracking-[0.2em]">Scroll</span>
        <div
          className="w-px h-10 bg-gradient-to-b from-stellar-dim to-transparent"
          style={{ animation: 'orbit-glow 2.5s ease-in-out infinite' }}
        />
      </div>

      <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-space-900 to-transparent pointer-events-none" />
    </section>
  )
}

// ── ExplorerSection ───────────────────────────────────────────────────────────

function ExplorerSection() {
  const [selectedPlanet, setSelectedPlanet] = useState<Planet | null>(null)
  const [isPlaying, setIsPlaying] = useState(true)
  const [timeSpeed, setTimeSpeed] = useState(1)
  const [cameraMode, setCameraMode] = useState('free')

  return (
    <section id="explorer" className="relative h-screen overflow-hidden">
      <SolarSystem
        selectedPlanet={selectedPlanet}
        onSelectPlanet={setSelectedPlanet}
        isPlaying={isPlaying}
      />

      <ExplorerStatusBar selectedPlanet={selectedPlanet} isPlaying={isPlaying} />

      {/* Version label */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 text-[10px] font-mono text-nk-cyan/30 uppercase tracking-[0.2em] pointer-events-none z-10 select-none">
        Neko Eyes · Solar System Explorer · v0.1
      </div>

      {/* Breadcrumb */}
      <div className="absolute top-9 left-1/2 -translate-x-1/2 pointer-events-none z-10">
        <div className="flex items-center gap-2 text-[11px] font-mono text-stellar-dim/35">
          <span>Solar System</span>
          {selectedPlanet && (
            <>
              <span className="text-stellar-dim/20">›</span>
              <span className="text-nk-cyan/55">{selectedPlanet.name}</span>
            </>
          )}
        </div>
      </div>

      {/* Floating UI */}
      <div className="absolute inset-0 pointer-events-none z-10">
        {/* Camera controls — top-left */}
        <div className="absolute top-16 left-4 pointer-events-auto">
          <CameraControls mode={cameraMode} onModeChange={setCameraMode} />
        </div>

        {/* Discovery hint — top-center (fades when something selected) */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 pointer-events-auto">
          <DiscoveryHint visible={!selectedPlanet} />
        </div>

        {/* Object info — top-right */}
        <div
          className={`absolute top-16 right-4 pointer-events-auto transition-all duration-350 ${
            selectedPlanet ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4 pointer-events-none'
          }`}
        >
          <ObjectInfoPanel planet={selectedPlanet} onClose={() => setSelectedPlanet(null)} />
        </div>

        {/* Planet selector — right center (desktop) */}
        <div className="absolute top-1/2 -translate-y-1/2 right-4 pointer-events-auto hidden lg:block">
          <PlanetSelector selected={selectedPlanet} onSelect={setSelectedPlanet} />
        </div>

        {/* Coordinates — bottom-left */}
        <div className="absolute bottom-10 left-4 pointer-events-auto hidden sm:block">
          <CoordinateDisplay />
        </div>

        {/* Time control — bottom-center */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 pointer-events-auto">
          <TimeControlBar
            isPlaying={isPlaying}
            onToggle={() => setIsPlaying(p => !p)}
            speed={timeSpeed}
            onSpeedChange={setTimeSpeed}
          />
        </div>

        {/* Mobile planet list */}
        <div className="absolute bottom-24 right-4 pointer-events-auto lg:hidden">
          <GlassPanel className="p-2">
            <div className="text-[10px] font-mono text-nk-cyan/50 uppercase tracking-widest px-1 mb-1">
              Objects
            </div>
            <div className="flex flex-col gap-0.5">
              {PLANETS.slice(0, 5).map(p => (
                <button
                  key={p.id}
                  className="flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-white/5 transition-all"
                  onClick={() => setSelectedPlanet(p)}
                >
                  <div className="rounded-full w-2 h-2 flex-shrink-0" style={{ background: p.color }} />
                  <span className="text-[10px] font-mono text-stellar-dim">{p.name}</span>
                </button>
              ))}
            </div>
          </GlassPanel>
        </div>
      </div>
    </section>
  )
}

// ── DesignSystemSection ───────────────────────────────────────────────────────

function DesignSystemSection() {
  const SectionTitle = ({ children }: { children: ReactNode }) => (
    <h3 className="font-display text-xl font-semibold text-stellar mb-6 flex items-center gap-3">
      <span className="w-px h-5 bg-nk-cyan/50" />
      {children}
    </h3>
  )

  const colors = [
    { name: 'Space 950', hex: '#010610', usage: 'Deepest BG' },
    { name: 'Space 900', hex: '#020813', usage: 'Body BG' },
    { name: 'Space 800', hex: '#050e1f', usage: 'Surface' },
    { name: 'Space 700', hex: '#0a1a33', usage: 'Elevated' },
    { name: 'Space 600', hex: '#112240', usage: 'Borders' },
    { name: 'Space 500', hex: '#1e3a5f', usage: 'Active BG' },
    { name: 'NK Cyan', hex: '#00d8ff', usage: 'Primary' },
    { name: 'NK Amber', hex: '#ff8c42', usage: 'Warm CTA' },
    { name: 'Stellar', hex: '#e2f0ff', usage: 'Text Primary' },
    { name: 'Stellar Dim', hex: '#7a9cc4', usage: 'Text Muted' },
    { name: 'Nebula Pink', hex: '#e040fb', usage: 'Accent' },
    { name: 'Nebula Blue', hex: '#448aff', usage: 'Info' },
  ]

  const typeScale = [
    { px: '72', weight: '700', label: 'Display XL', family: '"Exo 2"', specimen: 'Explore the Cosmos' },
    { px: '48', weight: '600', label: 'Display LG', family: '"Exo 2"', specimen: 'Solar System' },
    { px: '32', weight: '600', label: 'Display MD', family: '"Exo 2"', specimen: 'Jupiter' },
    { px: '20', weight: '500', label: 'Display SM', family: '"Exo 2"', specimen: 'Gas Giant · 5.20 AU' },
    { px: '16', weight: '400', label: 'Body Base', family: '"Inter"', specimen: 'Neko Eyes invites you to traverse the Solar System in real time.' },
    { px: '14', weight: '400', label: 'Body SM', family: '"Inter"', specimen: 'Secondary labels and descriptive captions.' },
    { px: '12', weight: '400', label: 'Mono Base', family: '"JetBrains Mono"', specimen: 'RA 10h 42m 31.8s  ·  Dec +22° 14′ 09″' },
    { px: '11', weight: '500', label: 'Mono XS', family: '"JetBrains Mono"', specimen: 'ORBIT_RADIUS: 5.20 AU  ·  STATUS: NOMINAL' },
  ]

  const gradients = [
    {
      name: 'Nebula Cyan',
      css: 'linear-gradient(135deg, #7df9ff 0%, #00d8ff 40%, #448aff 100%)',
      usage: 'Primary text gradient, hero title',
    },
    {
      name: 'Deep Space',
      css: 'linear-gradient(180deg, #010610 0%, #0a1a33 100%)',
      usage: 'Section backgrounds, depth',
    },
    {
      name: 'Warm Amber',
      css: 'linear-gradient(135deg, #ffdb9a 0%, #ff8c42 60%, #ff5252 100%)',
      usage: 'Warm CTAs, Sun glow accents',
    },
    {
      name: 'Stellar Glow',
      css: 'radial-gradient(circle at 40% 40%, rgba(0,216,255,0.35) 0%, rgba(68,138,255,0.1) 50%, transparent 75%)',
      usage: 'Focus rings, planet aura',
    },
    {
      name: 'Nebula Overlay',
      css: 'linear-gradient(180deg, rgba(1,6,16,0.7) 0%, rgba(5,14,31,0.25) 50%, rgba(2,8,19,0.9) 100%)',
      usage: 'Image readability overlays',
    },
    {
      name: 'Glass Surface',
      css: 'linear-gradient(135deg, rgba(10,26,51,0.65) 0%, rgba(5,15,40,0.85) 100%)',
      usage: 'Glassmorphism panels',
    },
  ]

  const shadows = [
    {
      name: 'Panel',
      value: '0 8px 32px rgba(0,0,0,0.5)',
      usage: 'Glass panels, cards',
    },
    {
      name: 'Cyan Glow',
      value: '0 0 24px 4px rgba(0,216,255,0.35)',
      usage: 'Selected states, focus',
    },
    {
      name: 'Sun Glow',
      value: '0 0 40px 12px rgba(255,200,50,0.55)',
      usage: 'Sun, warm highlights',
    },
    {
      name: 'Elevated',
      value: '0 20px 60px rgba(0,0,0,0.6), 0 4px 12px rgba(0,0,0,0.4)',
      usage: 'Modals, elevated panels',
    },
  ]

  const borders = [
    { name: 'Hairline', value: '1px solid rgba(0,216,255,0.1)', usage: 'Default panel border' },
    { name: 'Active', value: '1px solid rgba(0,216,255,0.35)', usage: 'Selected/active state' },
    { name: 'Subtle', value: '1px solid rgba(255,255,255,0.06)', usage: 'Dividers, subdued' },
    { name: 'Strong', value: '1px solid rgba(0,216,255,0.5)', usage: 'Focus, emphasized' },
    { name: 'Amber', value: '1px solid rgba(255,140,66,0.35)', usage: 'Warning, warm accent' },
    { name: 'Error', value: '1px solid rgba(255,82,82,0.35)', usage: 'Error state' },
  ]

  const spacings = [4, 8, 12, 16, 24, 32, 48, 64, 96]
  const radii = [
    { label: 'sm', value: '6px' },
    { label: 'md', value: '10px' },
    { label: 'lg', value: '14px' },
    { label: 'xl', value: '20px' },
    { label: '2xl', value: '28px' },
    { label: 'full', value: '9999px' },
  ]

  const blurs = [
    { label: 'xs', value: '4px', px: 40 },
    { label: 'sm', value: '8px', px: 50 },
    { label: 'md', value: '12px', px: 60 },
    { label: 'lg', value: '20px', px: 70 },
    { label: 'xl', value: '32px', px: 80 },
  ]

  return (
    <section id="design-system" className="relative bg-space-900 py-24 px-6 scroll-mt-16">
      <div
        className="absolute inset-0 bg-cover bg-center pointer-events-none"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1710270578658-847a60efb10c?w=1920&h=1080&fit=crop&auto=format)',
          opacity: 0.03,
        }}
      />
      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <div className="text-[11px] font-mono text-nk-cyan/55 uppercase tracking-[0.2em] mb-3">
            Foundation
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-stellar mb-4">
            Design System
          </h2>
          <p className="text-stellar-dim max-w-xl leading-relaxed">
            Tokens, typography, and visual language powering the Neko Eyes interface. Built for React + Tailwind CSS v4.
          </p>
        </div>

        {/* Colors */}
        <div className="mb-20">
          <SectionTitle>Color Palette</SectionTitle>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {colors.map(c => (
              <div key={c.name} className="group cursor-default">
                <div
                  className="w-full aspect-square rounded-xl mb-2 border border-white/6 group-hover:scale-105 transition-transform duration-200"
                  style={{ background: c.hex }}
                />
                <div className="text-[11px] font-mono text-stellar">{c.name}</div>
                <div className="text-[10px] font-mono text-stellar-dim/50 mt-0.5">{c.hex}</div>
                <div className="text-[10px] text-stellar-dim/35 mt-0.5">{c.usage}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Typography */}
        <div className="mb-20">
          <SectionTitle>Typography Scale</SectionTitle>
          <div className="space-y-0">
            {typeScale.map((t, i) => (
              <div
                key={i}
                className="flex items-baseline gap-4 md:gap-8 py-4 border-b border-white/5 hover:border-nk-cyan/12 transition-colors"
              >
                <div className="text-[10px] font-mono text-stellar-dim/40 w-24 md:w-32 flex-shrink-0 leading-tight">
                  <div className="text-stellar-dim/65">{t.label}</div>
                  <div className="mt-0.5">{t.px}px · {t.weight}</div>
                  <div className="mt-0.5 text-stellar-dim/28">{t.family}</div>
                </div>
                <div
                  className="text-stellar min-w-0 truncate"
                  style={{
                    fontSize: `${t.px}px`,
                    fontWeight: parseInt(t.weight),
                    fontFamily: `${t.family}, sans-serif`,
                    lineHeight: 1.2,
                  }}
                >
                  {t.specimen}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Gradients */}
        <div className="mb-20">
          <SectionTitle>Gradients</SectionTitle>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {gradients.map(g => (
              <div key={g.name} className="group">
                <div
                  className="w-full h-20 rounded-xl mb-3 border border-white/5 group-hover:scale-[1.02] transition-transform duration-200"
                  style={{ background: g.css }}
                />
                <div className="text-sm font-display font-semibold text-stellar">{g.name}</div>
                <div className="text-[10px] font-mono text-stellar-dim/45 mt-0.5 leading-relaxed break-all">{g.css.slice(0, 60)}…</div>
                <div className="text-[10px] text-stellar-dim/35 mt-1">{g.usage}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Shadows & Glow */}
        <div className="mb-20">
          <SectionTitle>Shadows &amp; Glow</SectionTitle>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {shadows.map(s => (
              <div key={s.name} className="bg-space-800 rounded-xl p-5 flex flex-col items-center justify-center gap-4 border border-white/5">
                <div
                  className="w-14 h-14 rounded-xl bg-space-700"
                  style={{ boxShadow: s.value }}
                />
                <div className="text-center">
                  <div className="text-sm font-display font-semibold text-stellar">{s.name}</div>
                  <div className="text-[10px] text-stellar-dim/35 mt-0.5">{s.usage}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Borders */}
        <div className="mb-20">
          <SectionTitle>Borders</SectionTitle>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {borders.map(b => (
              <div
                key={b.name}
                className="rounded-xl p-4 bg-space-800"
                style={{ border: b.value }}
              >
                <div className="text-sm font-display font-semibold text-stellar mb-1">{b.name}</div>
                <div className="text-[10px] font-mono text-stellar-dim/40 mb-2 leading-snug">{b.value}</div>
                <div className="text-[10px] text-stellar-dim/30">{b.usage}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Spacing */}
        <div className="mb-20">
          <SectionTitle>Spacing Scale</SectionTitle>
          <div className="flex flex-wrap items-end gap-6">
            {spacings.map(s => (
              <div key={s} className="flex flex-col items-center gap-2">
                <div className="bg-nk-cyan/22 rounded" style={{ width: s, height: s }} />
                <span className="text-[10px] font-mono text-stellar-dim/45">{s}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Border Radius + Blur */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-20">
          <div>
            <SectionTitle>Border Radius</SectionTitle>
            <div className="flex flex-wrap gap-5">
              {radii.map(r => (
                <div key={r.label} className="flex flex-col items-center gap-2">
                  <div
                    className="w-14 h-14 bg-space-700 border border-nk-cyan/12"
                    style={{ borderRadius: r.value }}
                  />
                  <div className="text-[10px] font-mono text-center">
                    <div className="text-stellar">{r.label}</div>
                    <div className="text-stellar-dim/38">{r.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <SectionTitle>Blur Levels</SectionTitle>
            <div className="flex gap-4 flex-wrap">
              {blurs.map(b => (
                <div key={b.label} className="flex flex-col items-center gap-2">
                  <div
                    className="rounded-xl relative overflow-hidden border border-white/8"
                    style={{ width: b.px, height: b.px }}
                  >
                    <div
                      className="absolute inset-0 bg-cover bg-center"
                      style={{
                        backgroundImage:
                          'url(https://images.unsplash.com/photo-1677926405168-fa86268b7295?w=200&h=200&fit=crop&auto=format)',
                      }}
                    />
                    <div
                      className="absolute inset-0"
                      style={{
                        background: 'rgba(5,15,40,0.5)',
                        backdropFilter: `blur(${b.value})`,
                      }}
                    />
                  </div>
                  <div className="text-[10px] font-mono text-center">
                    <div className="text-stellar">{b.label}</div>
                    <div className="text-stellar-dim/38">{b.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Glass Effects */}
        <div>
          <SectionTitle>Glass &amp; Transparencies</SectionTitle>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              {
                label: 'glass',
                spec: 'bg rgba(5,15,40) · α 72%\nblur 20px · sat 180%',
                s: { background: 'rgba(5,15,40,0.72)', backdropFilter: 'blur(20px) saturate(180%)' },
                border: '1px solid rgba(0,216,255,0.1)',
              },
              {
                label: 'glass-dark',
                spec: 'bg rgba(2,8,19) · α 88%\nblur 24px',
                s: { background: 'rgba(2,8,19,0.88)', backdropFilter: 'blur(24px)' },
                border: '1px solid rgba(255,255,255,0.06)',
              },
              {
                label: 'glass-light',
                spec: 'bg rgba(10,26,51) · α 50%\nblur 12px · sat 160%',
                s: { background: 'rgba(10,26,51,0.5)', backdropFilter: 'blur(12px) saturate(160%)' },
                border: '1px solid rgba(0,216,255,0.08)',
              },
            ].map(e => (
              <div
                key={e.label}
                className="rounded-xl p-5 relative overflow-hidden"
                style={{ border: e.border, ...e.s }}
              >
                <div
                  className="absolute inset-0 bg-cover bg-center pointer-events-none"
                  style={{
                    backgroundImage:
                      'url(https://images.unsplash.com/photo-1677926405168-fa86268b7295?w=400&h=300&fit=crop&auto=format)',
                    opacity: 0.2,
                  }}
                />
                <div className="relative">
                  <div className="font-mono text-[10px] text-nk-cyan/65 uppercase tracking-widest mb-1">{e.label}</div>
                  <div className="font-display font-semibold text-stellar mb-2">Panel Example</div>
                  <pre className="text-[10px] font-mono text-stellar-dim/50 whitespace-pre-wrap leading-relaxed">{e.spec}</pre>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// ── ComponentsSection ─────────────────────────────────────────────────────────

function ComponentsSection() {
  const [activeTab, setActiveTab] = useState('system')
  const [toggle1, setToggle1] = useState(false)
  const [toggle2, setToggle2] = useState(true)
  const [toggle3, setToggle3] = useState(true)
  const [sliderVal, setSliderVal] = useState(65)
  const [activeState, setActiveState] = useState<'default' | 'hover' | 'active' | 'disabled'>('default')

  const badges = [
    { label: 'Terrestrial', color: '#4B9CD3', bg: 'rgba(75,156,211,0.15)' },
    { label: 'Gas Giant', color: '#C88B3A', bg: 'rgba(200,139,58,0.15)' },
    { label: 'Ice Giant', color: '#7DE8E8', bg: 'rgba(125,232,232,0.15)' },
    { label: 'G-type Star', color: '#FFD700', bg: 'rgba(255,215,0,0.12)' },
    { label: 'Active', color: '#00D8FF', bg: 'rgba(0,216,255,0.12)' },
    { label: 'Nominal', color: '#7A9CC4', bg: 'rgba(122,156,196,0.1)' },
    { label: 'Warning', color: '#FF8C42', bg: 'rgba(255,140,66,0.12)' },
    { label: 'Critical', color: '#FF5252', bg: 'rgba(255,82,82,0.12)' },
    { label: 'Offline', color: '#445566', bg: 'rgba(68,85,102,0.2)' },
  ]

  const SectionTitle = ({ children }: { children: ReactNode }) => (
    <h3 className="font-display text-xl font-semibold text-stellar mb-6 flex items-center gap-3">
      <span className="w-px h-5 bg-nk-cyan/50" />
      {children}
    </h3>
  )

  const toggles = [
    { label: 'Show Orbit Rings', state: toggle1, setter: setToggle1 },
    { label: 'Asteroid Belt', state: toggle2, setter: setToggle2 },
    { label: 'Star Labels', state: toggle3, setter: setToggle3 },
  ]

  return (
    <section id="components" className="relative bg-space-800 py-24 px-6 scroll-mt-16">
      <div
        className="absolute inset-0 bg-cover bg-center pointer-events-none"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1712508818673-f9e3875b94b6?w=1920&h=1080&fit=crop&auto=format)',
          opacity: 0.04,
        }}
      />
      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-16">
          <div className="text-[11px] font-mono text-nk-cyan/55 uppercase tracking-[0.2em] mb-3">Library</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-stellar mb-4">Components</h2>
          <p className="text-stellar-dim max-w-xl leading-relaxed">
            Reusable UI building blocks with all principal states — Default, Hover, Active, Selected, Disabled.
          </p>
        </div>

        {/* Component States grid */}
        <div className="mb-16">
          <SectionTitle>Button States</SectionTitle>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="text-left text-[10px] font-mono text-stellar-dim/40 uppercase tracking-wider py-2 pr-4 w-28">Variant</th>
                  {['Default', 'Hover', 'Active / Focus', 'Disabled'].map(s => (
                    <th key={s} className="text-center text-[10px] font-mono text-stellar-dim/40 uppercase tracking-wider py-2 px-3">
                      {s}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  {
                    label: 'Primary',
                    states: [
                      { text: 'Primary', cls: 'bg-nk-cyan text-space-900 font-semibold border border-nk-cyan' },
                      { text: 'Primary', cls: 'bg-[#22e3ff] text-space-900 font-semibold border border-[#22e3ff] shadow-[0_0_20px_rgba(0,216,255,0.4)]' },
                      { text: 'Primary', cls: 'bg-nk-cyan/85 text-space-900 font-semibold border border-nk-cyan scale-95' },
                      { text: 'Primary', cls: 'bg-space-700 text-stellar-dim/30 border border-transparent cursor-not-allowed' },
                    ],
                  },
                  {
                    label: 'Secondary',
                    states: [
                      { text: 'Secondary', cls: 'glass border border-nk-cyan/25 text-nk-cyan' },
                      { text: 'Secondary', cls: 'bg-nk-cyan/15 border border-nk-cyan/45 text-nk-cyan shadow-[0_0_12px_rgba(0,216,255,0.15)]' },
                      { text: 'Secondary', cls: 'bg-nk-cyan/20 border border-nk-cyan/55 text-nk-cyan' },
                      { text: 'Secondary', cls: 'bg-space-700/50 border border-white/6 text-stellar-dim/30 cursor-not-allowed' },
                    ],
                  },
                  {
                    label: 'Ghost',
                    states: [
                      { text: 'Ghost', cls: 'border border-white/10 text-stellar-dim' },
                      { text: 'Ghost', cls: 'border border-white/20 text-stellar bg-white/5' },
                      { text: 'Ghost', cls: 'border border-nk-cyan/30 text-stellar bg-nk-cyan/8' },
                      { text: 'Ghost', cls: 'border border-white/5 text-stellar-dim/25 cursor-not-allowed' },
                    ],
                  },
                ].map(row => (
                  <tr key={row.label} className="border-t border-white/5">
                    <td className="text-[11px] font-mono text-stellar-dim/50 py-3 pr-4">{row.label}</td>
                    {row.states.map((state, si) => (
                      <td key={si} className="py-3 px-3 text-center">
                        <button
                          className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg font-mono text-xs transition-none ${state.cls}`}
                          disabled={si === 3}
                        >
                          {state.text}
                        </button>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Icon Buttons */}
        <div className="mb-16">
          <SectionTitle>Buttons with Icons</SectionTitle>
          <div className="flex flex-wrap gap-3 mb-4">
            <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-mono text-sm bg-nk-cyan text-space-900 font-semibold hover:bg-[#22e3ff] hover:shadow-[0_0_24px_rgba(0,216,255,0.4)] transition-all active:scale-95">
              <span>▶</span> Begin Exploration
            </button>
            <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-mono text-sm bg-nk-amber text-space-900 font-semibold hover:shadow-[0_0_24px_rgba(255,140,66,0.4)] transition-all active:scale-95">
              <span>◎</span> Track Object
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-mono text-sm glass border border-nk-cyan/25 text-nk-cyan hover:bg-nk-cyan/15 transition-all">
              <span>⊕</span> Add Object
            </button>
            <button className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-mono text-sm border border-white/10 text-stellar-dim hover:text-stellar hover:border-white/20 transition-all">
              <span>⟲</span> Reset View
            </button>
          </div>
          <div className="flex gap-2">
            {[['▶', 'Play'], ['⏸', 'Pause'], ['⚙', 'Settings'], ['◎', 'Focus'], ['⊕', 'Add'], ['✕', 'Close']].map(([icon, title]) => (
              <button
                key={title}
                title={title}
                className="w-10 h-10 flex items-center justify-center rounded-xl glass border border-white/10 text-stellar-dim hover:text-stellar hover:border-nk-cyan/25 transition-all"
              >
                {icon}
              </button>
            ))}
          </div>
        </div>

        {/* Badges */}
        <div className="mb-16">
          <SectionTitle>Badges</SectionTitle>
          <div className="flex flex-wrap gap-2">
            {badges.map(b => (
              <span
                key={b.label}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono border"
                style={{ color: b.color, background: b.bg, borderColor: `${b.color}30` }}
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: b.color }} />
                {b.label}
              </span>
            ))}
          </div>
        </div>

        {/* Glass panels */}
        <div className="mb-16">
          <SectionTitle>Glass Panels</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <GlassPanel className="p-5">
              <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-widest mb-2">Default</div>
              <div className="font-display text-lg font-semibold text-stellar mb-1">Mercury</div>
              <div className="text-sm text-stellar-dim">0.39 AU · Terrestrial</div>
            </GlassPanel>
            <GlassPanel className="p-5">
              <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-widest mb-2">With Tags</div>
              <div className="font-display text-lg font-semibold text-stellar mb-2">Jupiter</div>
              <div className="flex gap-1.5 flex-wrap">
                {['5.20 AU', '95 Moons', 'Gas Giant'].map(tag => (
                  <span key={tag} className="text-[11px] font-mono px-2 py-0.5 bg-white/5 rounded-md text-stellar-dim border border-white/5">{tag}</span>
                ))}
              </div>
            </GlassPanel>
            <GlassPanel className="p-5 border-nk-cyan/25">
              <div className="text-[10px] font-mono text-nk-cyan uppercase tracking-widest mb-2 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-nk-cyan animate-pulse" />
                Selected
              </div>
              <div className="font-display text-lg font-semibold text-stellar mb-1">Earth</div>
              <div className="text-sm text-stellar-dim mb-3">1.00 AU · 1 Moon</div>
              <button className="w-full py-2 rounded-lg bg-nk-cyan/15 text-nk-cyan border border-nk-cyan/30 text-[11px] font-mono hover:bg-nk-cyan/25 transition-all">
                Focus Camera
              </button>
            </GlassPanel>
          </div>
        </div>

        {/* Planet cards */}
        <div className="mb-16">
          <SectionTitle>Planet Cards</SectionTitle>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {PLANETS.slice(2, 6).map(p => (
              <div
                key={p.id}
                className="glass rounded-xl p-4 border border-nk-cyan/8 hover:border-nk-cyan/22 transition-all cursor-pointer group hover:-translate-y-1 hover:shadow-[0_8px_24px_rgba(0,0,0,0.4)]"
              >
                <div className="flex items-start justify-between mb-3">
                  <div
                    className="rounded-full"
                    style={{
                      width: 36,
                      height: 36,
                      background: `radial-gradient(circle at 35% 30%, ${p.color}cc, ${p.color})`,
                      boxShadow: `0 0 12px 3px ${p.glow}`,
                    }}
                  />
                  <span
                    className="text-[10px] font-mono px-2 py-0.5 rounded-full"
                    style={{ color: p.color, background: `${p.color}1a`, border: `1px solid ${p.color}35` }}
                  >
                    {p.type}
                  </span>
                </div>
                <div className="font-display font-semibold text-stellar group-hover:text-nk-cyan transition-colors">
                  {p.name}
                </div>
                <div className="text-[11px] font-mono text-stellar-dim/50 mt-0.5">
                  {p.distanceAU} AU · {p.moons} moon{p.moons !== 1 ? 's' : ''}
                </div>
                <p className="text-[11px] text-stellar-dim/45 mt-2 leading-relaxed line-clamp-2">{p.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="mb-16">
          <SectionTitle>Controls</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <GlassPanel className="p-5">
              <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-widest mb-4">Range Sliders</div>
              <div className="space-y-5">
                <div>
                  <div className="flex justify-between text-[11px] font-mono text-stellar-dim mb-2">
                    <span>Time Speed</span>
                    <span className="text-nk-cyan">×{(sliderVal / 10).toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={sliderVal}
                    onChange={e => setSliderVal(parseInt(e.target.value))}
                    className="w-full"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] font-mono text-stellar-dim mb-2">
                    <span>Zoom Level</span>
                    <span className="text-stellar">42%</span>
                  </div>
                  <input type="range" min="1" max="100" defaultValue="42" className="w-full" readOnly />
                </div>
              </div>
            </GlassPanel>

            <GlassPanel className="p-5">
              <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-widest mb-4">Toggles</div>
              <div className="space-y-3 mb-5">
                {toggles.map(({ label, state, setter }) => (
                  <div key={label} className="flex items-center justify-between">
                    <span className="text-sm text-stellar-dim font-mono">{label}</span>
                    <button
                      className={`relative w-10 h-5 rounded-full transition-all border ${
                        state ? 'bg-nk-cyan/25 border-nk-cyan/45' : 'bg-white/8 border-white/12'
                      }`}
                      onClick={() => setter((s: boolean) => !s)}
                    >
                      <div
                        className={`absolute top-0.5 w-4 h-4 rounded-full transition-all ${
                          state ? 'left-5 bg-nk-cyan shadow-[0_0_8px_rgba(0,216,255,0.6)]' : 'left-0.5 bg-stellar-dim/40'
                        }`}
                      />
                    </button>
                  </div>
                ))}
              </div>
              <div className="border-t border-white/5 pt-4">
                <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-widest mb-3">Tab Selector</div>
                <div className="flex glass-light rounded-xl p-1 gap-1">
                  {['System', 'Planets', 'Moons'].map(tab => (
                    <button
                      key={tab}
                      className={`flex-1 text-[11px] font-mono py-1.5 rounded-lg transition-all border ${
                        activeTab === tab.toLowerCase()
                          ? 'bg-nk-cyan/20 text-nk-cyan border-nk-cyan/30'
                          : 'text-stellar-dim hover:text-stellar border-transparent'
                      }`}
                      onClick={() => setActiveTab(tab.toLowerCase())}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>
            </GlassPanel>
          </div>
        </div>

        {/* Navigation + Explorer Reference */}
        <div>
          <SectionTitle>Navigation Items</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <GlassPanel className="p-2">
              {[
                { icon: '◎', label: 'Solar System', active: true, sub: '9 objects' },
                { icon: '○', label: 'Inner Planets', active: false, sub: 'Mercury — Mars' },
                { icon: '○', label: 'Outer Planets', active: false, sub: 'Jupiter — Neptune' },
                { icon: '◌', label: 'Asteroid Belt', active: false, sub: 'Coming soon', dim: true },
                { icon: '◌', label: 'Kuiper Belt', active: false, sub: 'Coming soon', dim: true },
              ].map(item => (
                <div
                  key={item.label}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all border group ${
                    item.active ? 'bg-nk-cyan/10 border-nk-cyan/22' : 'hover:bg-white/5 border-transparent'
                  }`}
                >
                  <span className={`text-sm flex-shrink-0 ${item.active ? 'text-nk-cyan' : item.dim ? 'text-stellar-dim/22' : 'text-stellar-dim'}`}>
                    {item.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className={`text-sm font-mono ${item.active ? 'text-nk-cyan' : item.dim ? 'text-stellar-dim/28' : 'text-stellar-dim'}`}>
                      {item.label}
                    </div>
                    {item.sub && (
                      <div className="text-[10px] text-stellar-dim/30 mt-0.5">{item.sub}</div>
                    )}
                  </div>
                  {item.active && <span className="w-1.5 h-1.5 rounded-full bg-nk-cyan animate-pulse flex-shrink-0" />}
                </div>
              ))}
            </GlassPanel>

            {/* Explorer controls reference */}
            <GlassPanel className="p-4">
              <div className="text-[10px] font-mono text-nk-cyan/55 uppercase tracking-widest mb-4">
                Explorer Controls Reference
              </div>
              <div className="space-y-2.5">
                {[
                  { key: 'Click planet/sun', action: 'Select object + show info panel' },
                  { key: '▶ / ⏸', action: 'Play / pause orbital animations' },
                  { key: '×0.1 → ×10', action: 'Adjust simulation time speed' },
                  { key: 'Free', action: 'Free-roam camera movement' },
                  { key: 'Orbit', action: 'Orbit around selected object' },
                  { key: 'Track', action: 'Follow selected object in motion' },
                  { key: '− / +', action: 'Zoom in / zoom out' },
                  { key: '⟲ Reset', action: 'Return to default view' },
                ].map(({ key, action }) => (
                  <div key={key} className="flex items-start gap-3 border-b border-white/4 pb-2 last:border-b-0 last:pb-0">
                    <span className="text-[11px] font-mono text-nk-cyan/65 w-28 flex-shrink-0 mt-0.5">{key}</span>
                    <span className="text-[11px] text-stellar-dim/55 leading-snug">{action}</span>
                  </div>
                ))}
              </div>
            </GlassPanel>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Footer ────────────────────────────────────────────────────────────────────

function Footer() {
  return (
    <footer className="bg-space-950 border-t border-white/5 py-10 px-6">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2.5">
          <img src={nekoLogo} alt="Neko Eyes logo" className="w-7 h-7 object-contain opacity-75" />
          <span className="font-display font-semibold text-stellar text-sm">
            Neko<span className="text-nk-cyan"> Eyes</span>
          </span>
          <span className="text-[10px] font-mono text-stellar-dim/22 border border-white/6 px-2 py-0.5 rounded">
            V0
          </span>
        </div>
        <div className="flex items-center gap-3 text-[11px] font-mono text-stellar-dim/30">
          <span>Solar System Explorer</span>
          <span className="text-stellar-dim/15">·</span>
          <span>Conception UI/UX</span>
          <span className="text-stellar-dim/15">·</span>
          <span>2025</span>
        </div>
        <div className="text-[10px] font-mono text-stellar-dim/22">
          React 19 · Tailwind CSS v4
        </div>
      </div>
    </footer>
  )
}

// ── App ───────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <div className="min-h-screen bg-space-900">
      <Header />
      <main>
        <HeroSection />
        <ExplorerSection />
        <DesignSystemSection />
        <ComponentsSection />
      </main>
      <Footer />
    </div>
  )
}
